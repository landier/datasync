"""
This is a simplistic skeleton to help you start the use case.
In any case feel free to use it or not.
"""

import fetch_and_load


def main():
    """Main function to fetch data from the API and to store it in DB.

    Returns:
        True for success, False otherwise.

    """
    return fetch_and_load.all()


if __name__ == "__main__":
    main()

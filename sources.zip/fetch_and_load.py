from fetch_from_api import fetch_from_api
from push_to_db import push_to_db


def all():
    data = fetch_from_api()
    push_to_db(data)
    return True

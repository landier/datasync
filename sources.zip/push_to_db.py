from snowflake import connector as snowflake

SNFLK_USER = "ITW_USER"
SNFLK_PASSWORD = "GhBAMXwHBtm-vJz7ewqR"
SNFLK_ACCOUNT = "db93014.eu-west-1"
SNFLK_ROLE = "ITW_ROLE"
SNFLK_WAREHOUSE = "WH_ITW"
SNFLK_DATABASE = "SPX_INTERVIEW"
SNFLK_SCHEMA = "PUBLIC"

connection = snowflake.connect(
    user=SNFLK_USER,
    password=SNFLK_PASSWORD,
    account=SNFLK_ACCOUNT,
    warehouse=SNFLK_WAREHOUSE,
    database=SNFLK_DATABASE,
    schema=SNFLK_SCHEMA,
    role=SNFLK_ROLE,
)
cursor = connection.cursor()


def push_to_db(d):
    execute_query = (
        "MERGE INTO  INTERVIEW.PUBLIC.EXAMPLE_TABLE AS TARGET  "
        "USING  (SELECT 'id_1' as ID, 'name_1' AS NAME) AS NEW_VALUES  "
        "ON TARGET.ID = NEW_VALUES.ID "
        "WHEN MATCHED THEN UPDATE SET TARGET.NAME = NEW_VALUES.NAME "
        "WHEN NOT MATCHED THEN INSERT (ID, NAME) "
        "VALUES (NEW_VALUES.ID, NEW_VALUES.NAME) ;"
    )
    cursor.execute(execute_query)
    connection.commit()

import json
import requests

API_URL = "https://00ij5gk51d.execute-api.eu-west-1.amazonaws.com/accounts"


def fetch_from_api():
    response = requests.get(API_URL).json()
    print(json.dumps(response, indent=3))

    return response
